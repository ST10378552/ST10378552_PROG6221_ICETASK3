namespace IceTask3_ST10378552
{
    public partial class Form1 : Form
    {
        private Dictionary<string, decimal> menu = new Dictionary<string, decimal>()
        {
            { "Coffee", 2.50m },
            { "Tea", 2.00m },
            { "Sandwich", 5.00m },
            { "Cake", 3.50m }
        };

        private List<Tuple<string, int>> order = new List<Tuple<string, int>>();

        public Form1()
        {
            InitializeComponent();
            PopulateComboBox();
        }
        private void PopulateComboBox()
        {
            foreach (var item in menu.Keys)
            {
                comboBoxItems.Items.Add(item);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectedItem = comboBoxItems.SelectedItem?.ToString();
            if (selectedItem != null)
            {
                int quantity = (int)numericUpDownQuantity.Value;
                order.Add(new Tuple<string, int>(selectedItem, quantity));
                MessageBox.Show("Item added to order.");
            }
            else
            {
                MessageBox.Show("Please select an item.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            decimal total = 0;
            string receipt = "Receipt:\n";
            foreach (var item in order)
            {
                decimal price = menu[item.Item1];
                decimal subtotal = price * item.Item2;
                receipt += $"{item.Item1} (x{item.Item2}): ${price} each, Total: ${subtotal}\n";
                total += subtotal;
            }
            receipt += $"\nTotal: ${total}";
            MessageBox.Show(receipt, "Order Receipt");

        }


    }
}
